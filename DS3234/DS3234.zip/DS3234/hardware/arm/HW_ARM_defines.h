// *** Hardware SPI-specific defines
#define SPI_CLOCK_4MHZ		0x15

#define SPI_CLOCK_DEFAULT	0x15  // DS3234 only supports up to 4MHz

#define SPI_CHIP_SEL 3
