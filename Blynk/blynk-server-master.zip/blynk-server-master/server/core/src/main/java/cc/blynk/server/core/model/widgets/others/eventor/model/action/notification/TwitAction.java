package cc.blynk.server.core.model.widgets.others.eventor.model.action.notification;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 01.08.16.
 */
public class TwitAction extends NotificationAction {

    public TwitAction() {
    }

    public TwitAction(String message) {
        this.message = message;
    }

}
