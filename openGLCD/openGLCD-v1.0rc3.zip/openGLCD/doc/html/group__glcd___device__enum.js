var group__glcd___device__enum =
[
    [ "BLACK", "group__glcd___device__enum.html#ga7b3b25cba33b07c303f3060fe41887f6", null ],
    [ "PIXEL_OFF", "group__glcd___device__enum.html#gacda2f1b1cf6310700d0d91643c40e068", null ],
    [ "PIXEL_ON", "group__glcd___device__enum.html#gaeb2d212a26da4a5a4d3231b2773023e5", null ],
    [ "WHITE", "group__glcd___device__enum.html#ga87b537f5fa5c109d3c05c13d6b18f382", null ],
    [ "glcd_device_mode", "group__glcd___device__enum.html#ga157abf7f46fa0bb87bb1cd10e5b7c12d", [
      [ "NON_INVERTED", "group__glcd___device__enum.html#gga157abf7f46fa0bb87bb1cd10e5b7c12da049148d3a888cdb3701ea38058ff5822", null ],
      [ "INVERTED", "group__glcd___device__enum.html#gga157abf7f46fa0bb87bb1cd10e5b7c12da1e172b06bae2f97e733787d76106800e", null ]
    ] ]
];