package cc.blynk.server.notifications.mail.http;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 14.09.16.
 */
public class Options {

    public final boolean open_tracking = false;

    public final boolean click_tracking = false;

}
