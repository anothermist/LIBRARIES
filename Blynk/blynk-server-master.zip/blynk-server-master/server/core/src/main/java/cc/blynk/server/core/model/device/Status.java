package cc.blynk.server.core.model.device;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 16.12.16.
 */
public enum Status {

    ONLINE,
    OFFLINE

}
