package cc.blynk.server.api.http.pojo.att;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 29.07.16.
 */
public class AttDevice {

    public String id;

    public String name;

    public String serial;

}
