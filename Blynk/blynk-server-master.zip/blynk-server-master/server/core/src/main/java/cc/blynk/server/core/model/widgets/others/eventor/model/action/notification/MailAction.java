package cc.blynk.server.core.model.widgets.others.eventor.model.action.notification;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 01.08.16.
 */
public class MailAction extends NotificationAction {

    public MailAction() {
    }

    public MailAction(String message) {
        this.message = message;
    }

}
