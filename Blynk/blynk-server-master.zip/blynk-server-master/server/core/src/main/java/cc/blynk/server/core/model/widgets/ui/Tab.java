package cc.blynk.server.core.model.widgets.ui;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 10.03.16.
 */
public class Tab {

    public String label;

}
