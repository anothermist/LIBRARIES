package cc.blynk.server.core.model.widgets.ui.table;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 07.09.16.
 */
public class Column {

    public String name;

}
