package cc.blynk.server.api.http.logic.business;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 13.05.16.
 */
public class Cookies {

    public static final String SESSION_COOKIE = "session";

}
