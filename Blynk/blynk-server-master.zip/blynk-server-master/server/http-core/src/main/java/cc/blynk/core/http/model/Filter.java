package cc.blynk.core.http.model;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 07.12.15.
 */
public class Filter {

    public String name;

}
