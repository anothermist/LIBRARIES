# AM2320
Ten AM2320 i2c temperature and humidity sensor arduino library.
Just, implemented basic temperature and humidity values reading.
NOTE: user written code should include the wire.h library.

Wire.begin() is expected to be called before any call to AM2320::Read().
(eg. in the sketch setup() function).


Note: Tested on ESP8266/Arduino. 

