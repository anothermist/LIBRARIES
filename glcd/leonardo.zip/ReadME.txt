This is a very early pre-release set of files for Leonardo pin mapping testing.
It allows testing with Leonardo, Micro, and LillyPadUSB.
It is not intended to be the final files nor have the full panel
support of a full distribution.
It is to allow testing of pin mappings and pin configuration for
the Arduino Inc. 32u4 based boards.

Pin # assignments and Wiring for Leonardo/Micro/LillyPad-USB are exactly the same as for standard Arduino/Uno.
This allow swapping out a working Arduino board with a Leonardo board.

The modified files are:
arduino_io.h (goes in glcd/include)
ks0108_Leonardo.h (goes in glcd/config)
ks0108_Panel.h (goes in glcd/config)
GLCDdiags.pde (goes in glcd/examples/GLCDdiags

copy these files into those directories and then build and run
the glcd diag sketch.

The Leonardo/Micro/LillyPad-USB will all use the
ks010_Leonardo.h config file
