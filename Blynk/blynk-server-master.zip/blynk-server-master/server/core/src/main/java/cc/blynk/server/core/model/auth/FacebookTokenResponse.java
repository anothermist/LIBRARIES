package cc.blynk.server.core.model.auth;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 25.09.16.
 */
public class FacebookTokenResponse {

    public String email;

}
