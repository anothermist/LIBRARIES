package cc.blynk.server.notifications.push;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 26.06.15.
 */
public class GCMResult {

    public String error;

}
