package cc.blynk.server.api.http.pojo.att;

import java.util.Date;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 29.07.16.
 */
public class AttValue {

    public String value;

    public Date timestamp;

    public String unit;

}
