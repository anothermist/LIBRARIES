var searchData=
[
  ['additional_20resources',['Additional Resources',['../page__additional_resources.html',1,'index']]],
  ['arduino_20print_20functions',['Arduino print Functions',['../page_arduino_print.html',1,'page_GLCD_API']]]
];
