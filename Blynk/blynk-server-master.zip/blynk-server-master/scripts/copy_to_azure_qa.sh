#!/bin/sh

scp ../server/launcher/target/server-0.23.0-SNAPSHOT.jar azureuser@blynk-qa.cloudapp.net:/home/azureuser