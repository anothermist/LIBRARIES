var searchData=
[
  ['using_20bitmaps',['Using Bitmaps',['../page__bitmaps.html',1,'page_FontsBitmaps']]],
  ['using_20fonts',['Using Fonts',['../page__fonts.html',1,'page_FontsBitmaps']]]
];
