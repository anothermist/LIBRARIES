package cc.blynk.server.notifications.mail.http;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 14.09.16.
 */
class Recipient {

    public final String address;

    public Recipient(String address) {
        this.address = address;
    }

}
