var searchData=
[
  ['readdata',['ReadData',['../classglcd.html#abe22f47712e6a01c65e1f5e4b1023028',1,'glcd::ReadData()'],['../classglcd___device.html#abe22f47712e6a01c65e1f5e4b1023028',1,'glcd_Device::ReadData()']]],
  ['right',['Right',['../classglcd.html#a6f1db2d3e921d6c346eb537abfac886b',1,'glcd']]]
];
